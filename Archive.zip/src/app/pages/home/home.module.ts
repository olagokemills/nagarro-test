import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopStoriesComponent } from './top-stories/top-stories.component';
import { HomeComponent } from './home.component';
import { HomeRoutes } from './home.routes';
import { RouterModule } from '@angular/router';
import { StoryDetailsComponent } from './story-details/story-details.component';


@NgModule({
  declarations: [TopStoriesComponent,HomeComponent, StoryDetailsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(HomeRoutes),
  ]
})
export class HomeModule { }

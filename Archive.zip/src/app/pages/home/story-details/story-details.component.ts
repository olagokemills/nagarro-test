import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-story-details',
  templateUrl: './story-details.component.html',
  styleUrls: ['./story-details.component.css']
})
export class StoryDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

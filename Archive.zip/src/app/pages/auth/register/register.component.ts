import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GlobalsService } from 'src/app/core/globals/Globals.service';
import { Users } from 'src/app/core/model/users.model';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  RegisterForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private gVars:GlobalsService
  ) { }

  ngOnInit(): void {
    this.RegisterForm = this.fb.group({
      email:['',[Validators.email,Validators.required]],
      password:['',[Validators.required,Validators.minLength(3)]]
    })
  }

  Register(data:Users)
  {
    this.authService.Register(data).subscribe(
      (res:any)=>{
        if(!res)
        {
          this.gVars.toastr.error(res.message)
        }
        else{
          this.gVars.toastr.success("Registration Successful!")
          sessionStorage.setItem('jwt',res.access_token)
        }
      }
    )
  }
}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GlobalsService } from 'src/app/core/globals/Globals.service';
import { Users } from 'src/app/core/model/users.model';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  LoginForm:FormGroup
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private gVars:GlobalsService
  ) { }

  ngOnInit(): void {
    this.LoginForm = this.fb.group({
      email:['',[Validators.email,Validators.required]],
      password:['',[Validators.required,Validators.minLength(3)]]
    })
  }
  Login(data:Users)
  {
    this.authService.Login(data).subscribe(
      (res:any)=>{
        if(!res)
        {
          this.gVars.toastr.error("Invalid login details")
        }
        else{
          sessionStorage.setItem('jwt',res.access_token)
        }
      }
    )
  }

}

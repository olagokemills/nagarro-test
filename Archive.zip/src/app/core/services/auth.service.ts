import { Injectable } from "@angular/core";
import { Users } from '../model/users.model'
import { HttpClient } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { of } from "rxjs";
import { tap,catchError } from "rxjs/operators"

@Injectable({
    providedIn:'root'
})

export class AuthService{

    constructor(
        private http: HttpClient
    )
    {}

    Login(data:Users)
    {
        return this.http.post(`${environment.apis.authServer}/Login`, data)
        .pipe(tap(data=>{
            //set uSER
        }))
        .pipe(catchError(err=>{
            return of(false)
        }))
    } 
    Register(data:Users)
    {
        return this.http.post(`${environment.apis.authServer}/register`, data)
    } 
    //0rTBMW5k8JFwP4hxRbxEjTb4lmE8kru5
}
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { Observable, of } from "rxjs";
import { tap,catchError } from "rxjs/operators"
import { Stories } from "../model/stories.model";


@Injectable({
    providedIn:'root'
})

export class StoriesService{

    constructor(
        private http: HttpClient
    )
    {}
    
    FetchTopStories():Observable<Stories[]>
    {
        return this.http.get<Stories[]>(`${environment.apis.storiesServer}/home.json?api-key=${environment.key}`)
    }
    // FetchComments(data)
    // {
    //     return this.http.get<any>(`${environment.apis.commentsServer}/url.json?api-key=${environment.key}&offset=10&url=${data}`,{
    //         // headers: new HttpHeaders({
    //         //     'Authorization': 'my-token'
    //         // })
    //     })
    // }

    FetchComments(data)
    {
        return this.http.get<any>(`https://api.nytimes.com/svc/community/v3/user-content/url.json?api-key=0rTBMW5k8JFwP4hxRbxEjTb4lmE8kru5&offset=10&url=https://www.nytimes.com/2021/11/16/nyregion/outdoor-dining-nyc.html`
            
        // ,{
        //    headers: new HttpHeaders({
        //         'Authorization': 'my-token'
        //     }) 
        // } 
        )  
    }

    

}
